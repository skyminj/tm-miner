#!/bin/sh

while [ 1 ]; do
./sugarmaker -a YespowerTIDE -o stratum+tcp://tidemine.xyz:3332 -u WALLET_ADDRESS.WORKER_NAME
sleep 5
done
