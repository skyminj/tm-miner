source - https://github.com/likloadm/sugarmaker
