#!/bin/sh

#This is an example you can edit and use
#There are numerous parameters you can set, please check Help and Examples folder

./SRBMiner-MULTI --disable-gpu --algorithm yespowertide --pool tidemine.xyz:3332 -u WALLET_ADDRESS.WORKER_NAME
